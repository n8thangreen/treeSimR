library(testthat)
library(treeSimR)

test_check("treeSimR")
