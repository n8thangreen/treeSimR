
#' fill_in_missing_tree_probs
#'
#' For binary tree only i.e. event/no event
#'
#' @param osNode
#'
#' @return fill filled-in probabilities
#' @export
#'
#' @examples
#'
#' pname <- "pmin"
#' osNode <- osNode.cost_pdistn
#'
fill_in_missing_tree_probs <- function(osNode,
                                       pname) {

  df <- data.frame(level = osNode$Get("level"),
                   pmin = as.numeric(as.character(osNode$Get(pname))))

  df$id <- seq_len(nrow(df))

  fill <- df[[pname]]
  df$keep <- TRUE

  while (max(df$level) != 1) {

    for (i in seq_len(nrow(df) - 1)) {

      if (df$level[i] == df$level[i + 1]) {

        if (any(is.na(df[i, pname]), is.na(df[i + 1, pname]))) {

          na_entry <- which(is.na(c(df[i, pname], df[i + 1, pname]))) - 1
          fill[df$id[i + na_entry]] <- 1 - df[i + 1 - na_entry, pname]
        }

        df$keep[c(i, i + 1)] <- c(FALSE, FALSE)
      }
    }

    df <- df[df$keep, ]
  }

  return(fill)
}



